import cv2

image_path = '../faces/messi/messi_1.jpeg'
image = cv2.imread(image_path)
cv2.imshow('Original', image)
new_image = cv2.convertScaleAbs(image, alpha=1, beta=100)
cv2.imshow('Edited', new_image)
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
ret, otsu = cv2.threshold(image, 0, 255, cv2.THRESH_OTSU)
cv2.imshow('OTSU', otsu)
cv2.waitKey(0)
cv2.destroyAllWindows() 


#histogram equalization
#threshold and simple segmentation